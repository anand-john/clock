import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlarmClock,
  Bell,
  BellOff,
  Check,
  ChevronDown,
  Clock3,
  CloudSun,
  Edit3,
  Info,
  Moon,
  MoreHorizontal,
  Pause,
  Plus,
  RotateCcw,
  Settings2,
  ShieldCheck,
  Sparkles,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

type Sound = 'soft-rise' | 'morning-bells' | 'woodland';
type RepeatDay = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';
type Alarm = {
  id: string;
  time: string;
  label: string;
  repeat: RepeatDay[];
  sound: Sound;
  enabled: boolean;
  snoozeUntil?: number;
};
type FormState = Omit<Alarm, 'id'>;

const STORAGE_KEY = 'sunroom-alarm-clock-v1';
const DAYS: { key: RepeatDay; label: string; name: string }[] = [
  { key: 'mon', label: 'M', name: 'Monday' },
  { key: 'tue', label: 'T', name: 'Tuesday' },
  { key: 'wed', label: 'W', name: 'Wednesday' },
  { key: 'thu', label: 'T', name: 'Thursday' },
  { key: 'fri', label: 'F', name: 'Friday' },
  { key: 'sat', label: 'S', name: 'Saturday' },
  { key: 'sun', label: 'S', name: 'Sunday' },
];
const SOUNDS: { key: Sound; label: string; detail: string }[] = [
  { key: 'soft-rise', label: 'Soft rise', detail: 'A slow, warm swell' },
  { key: 'morning-bells', label: 'Morning bells', detail: 'Bright and familiar' },
  { key: 'woodland', label: 'Woodland', detail: 'Airy, with a little space' },
];
const queryClient = new QueryClient();

function pad(value: number) {
  return value.toString().padStart(2, '0');
}

function formatTime(date: Date) {
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function formatDate(date: Date) {
  return date.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });
}

function daysText(repeat: RepeatDay[]) {
  if (!repeat.length) return 'Once';
  if (repeat.length === 7) return 'Every day';
  if (repeat.join(',') === ['mon', 'tue', 'wed', 'thu', 'fri'].join(',')) return 'Weekdays';
  if (repeat.join(',') === ['sat', 'sun'].join(',')) return 'Weekends';
  return repeat.map((day) => DAYS.find((item) => item.key === day)?.name.slice(0, 3)).join(' · ');
}

function makeId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function loadAlarms(): Alarm[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return JSON.parse(stored) as Alarm[];
  } catch {
    // A clean start is preferable to a broken bedside companion.
  }
  return [{
    id: makeId(),
    time: '07:00',
    label: 'A gentle start',
    repeat: ['mon', 'tue', 'wed', 'thu', 'fri'],
    sound: 'soft-rise',
    enabled: true,
  }];
}

function getNextAlarm(alarms: Alarm[], now: Date) {
  const candidates = alarms.filter((alarm) => alarm.enabled).map((alarm) => {
    const [hour, minute] = alarm.time.split(':').map(Number);
    for (let offset = 0; offset < 8; offset += 1) {
      const date = new Date(now);
      date.setDate(now.getDate() + offset);
      date.setHours(hour, minute, 0, 0);
      const dayKey = DAYS[(date.getDay() + 6) % 7].key;
      if ((!alarm.repeat.length || alarm.repeat.includes(dayKey)) && date.getTime() > now.getTime()) {
        return { alarm, date };
      }
    }
    return null;
  }).filter((item): item is { alarm: Alarm; date: Date } => Boolean(item));
  return candidates.sort((a, b) => a.date.getTime() - b.date.getTime())[0] ?? null;
}

function useClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);
  return now;
}

function useAlarmTone() {
  const contextRef = useRef<AudioContext | null>(null);
  const nodesRef = useRef<OscillatorNode[]>([]);
  const start = useCallback(async (sound: Sound) => {
    const AudioContextClass = window.AudioContext ?? (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return false;
    const context = contextRef.current ?? new AudioContextClass();
    contextRef.current = context;
    try {
      await context.resume();
      nodesRef.current.forEach((node) => node.stop());
      nodesRef.current = [];
      const frequencies = sound === 'morning-bells' ? [523.25, 659.25, 783.99] : sound === 'woodland' ? [392, 493.88] : [329.63, 440];
      frequencies.forEach((frequency, index) => {
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        oscillator.type = sound === 'woodland' ? 'sine' : 'triangle';
        oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0.0001, context.currentTime);
        gain.gain.linearRampToValueAtTime(.075, context.currentTime + .35 + index * .12);
        gain.gain.linearRampToValueAtTime(0.0001, context.currentTime + 2.2 + index * .12);
        oscillator.connect(gain).connect(context.destination);
        oscillator.start();
        oscillator.stop(context.currentTime + 2.5 + index * .12);
        nodesRef.current.push(oscillator);
      });
      return true;
    } catch {
      return false;
    }
  }, []);
  const stop = useCallback(() => {
    nodesRef.current.forEach((node) => {
      try { node.stop(); } catch { /* already stopped */ }
    });
    nodesRef.current = [];
  }, []);
  return { start, stop };
}

function AppContent() {
  const now = useClock();
  const { start, stop } = useAlarmTone();
  const [alarms, setAlarms] = useState<Alarm[]>(loadAlarms);
  const [isEditorOpen, setEditorOpen] = useState(false);
  const [editingAlarm, setEditingAlarm] = useState<Alarm | null>(null);
  const [ringingAlarm, setRingingAlarm] = useState<Alarm | null>(null);
  const [audioReady, setAudioReady] = useState(false);
  const [audioBlocked, setAudioBlocked] = useState(false);
  const [toast, setToast] = useState('');
  const firedRef = useRef(new Set<string>());

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(alarms));
  }, [alarms]);

  const next = useMemo(() => getNextAlarm(alarms, now), [alarms, now]);
  const enabledCount = alarms.filter((alarm) => alarm.enabled).length;

  const flash = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(''), 2800);
  }, []);

  const unlockAudio = useCallback(async () => {
    const worked = await start('soft-rise');
    setAudioReady(worked);
    if (worked) flash('Sound is ready for the morning.');
    else flash('Sound needs a tap from this page to begin.');
  }, [flash, start]);

  const triggerAlarm = useCallback(async (alarm: Alarm) => {
    setRingingAlarm(alarm);
    const worked = await start(alarm.sound);
    setAudioBlocked(!worked);
  }, [start]);

  useEffect(() => {
    const check = () => {
      const current = new Date();
      alarms.forEach((alarm) => {
        if (!alarm.enabled) return;
        if (alarm.snoozeUntil) {
          if (current.getTime() >= alarm.snoozeUntil && !firedRef.current.has(`${alarm.id}-snooze`)) {
            firedRef.current.add(`${alarm.id}-snooze`);
            void triggerAlarm(alarm);
          }
          return;
        }
        const [hour, minute] = alarm.time.split(':').map(Number);
        const dayKey = DAYS[(current.getDay() + 6) % 7].key;
        const key = `${alarm.id}-${current.toDateString()}`;
        const dayMatches = alarm.repeat.length ? alarm.repeat.includes(dayKey) : true;
        if (current.getHours() === hour && current.getMinutes() === minute && dayMatches && !firedRef.current.has(key)) {
          firedRef.current.add(key);
          void triggerAlarm(alarm);
        }
      });
    };
    check();
    const timer = window.setInterval(check, 1000);
    return () => window.clearInterval(timer);
  }, [alarms, triggerAlarm]);

  const openNew = () => {
    setEditingAlarm(null);
    setEditorOpen(true);
  };

  const openEdit = (alarm: Alarm) => {
    setEditingAlarm(alarm);
    setEditorOpen(true);
  };

  const saveAlarm = (form: FormState) => {
    if (editingAlarm) {
      setAlarms((current) => current.map((alarm) => alarm.id === editingAlarm.id ? { ...form, id: alarm.id } : alarm));
      flash('Alarm updated.');
    } else {
      setAlarms((current) => [...current, { ...form, id: makeId() }]);
      flash('Alarm set. Sleep easy.');
    }
    setEditorOpen(false);
  };

  const toggleAlarm = (id: string) => {
    setAlarms((current) => current.map((alarm) => alarm.id === id ? { ...alarm, enabled: !alarm.enabled } : alarm));
  };

  const deleteAlarm = (id: string) => {
    setAlarms((current) => current.filter((alarm) => alarm.id !== id));
    flash('Alarm removed.');
  };

  const quickTest = () => {
    const testDate = new Date(Date.now() + 65_000);
    const testAlarm: Alarm = {
      id: makeId(),
      time: `${pad(testDate.getHours())}:${pad(testDate.getMinutes())}`,
      label: 'One-minute test',
      repeat: [],
      sound: 'morning-bells',
      enabled: true,
    };
    setAlarms((current) => [...current, testAlarm]);
    flash(`Test alarm set for ${formatTime(testDate)}.`);
  };

  const dismiss = () => {
    if (!ringingAlarm) return;
    stop();
    setAlarms((current) => current.map((alarm) => alarm.id === ringingAlarm.id ? { ...alarm, snoozeUntil: undefined } : alarm));
    setRingingAlarm(null);
    setAudioBlocked(false);
  };

  const snooze = () => {
    if (!ringingAlarm) return;
    stop();
    const snoozeUntil = Date.now() + 9 * 60 * 1000;
    setAlarms((current) => current.map((alarm) => alarm.id === ringingAlarm.id ? { ...alarm, snoozeUntil } : alarm));
    firedRef.current.delete(`${ringingAlarm.id}-snooze`);
    setRingingAlarm(null);
    flash('Snoozed for 9 minutes.');
  };

  return (
    <div className="grain app-shell min-h-[100dvh]">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5 sm:px-8 lg:px-10">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-[1.05rem] bg-[#233947] text-[#f7d99b] shadow-[0_8px_20px_rgba(35,57,71,.18)]">
            <AlarmClock size={20} strokeWidth={1.8} />
          </div>
          <div>
            <p className="text-[15px] font-semibold tracking-[-.02em]">Sunroom</p>
            <p className="text-[11px] uppercase tracking-[.18em] text-muted-foreground">A quieter wake-up</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {!audioReady && (
            <button data-testid="button-enable-sound" onClick={() => void unlockAudio()} className="button-lift hidden items-center gap-2 rounded-full border border-[#d6c9ab] bg-[#fbf6e9] px-3.5 py-2 text-xs font-medium text-[#53605c] sm:flex">
              <Volume2 size={14} /> Enable sound
            </button>
          )}
          <button data-testid="button-settings" onClick={() => flash('Your alarms are saved only on this device.')} aria-label="Open settings" className="button-lift flex h-10 w-10 items-center justify-center rounded-full border border-border/70 bg-card/60 text-muted-foreground">
            <Settings2 size={17} />
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-14 sm:px-8 lg:px-10">
        <section className="relative overflow-hidden rounded-[2rem] border border-[#e3d5bb] bg-[#f9f1dc] px-6 pb-8 pt-7 shadow-[0_20px_60px_rgba(113,82,49,.08)] sm:px-10 sm:pb-10 sm:pt-9">
          <div className="absolute -right-16 -top-24 h-72 w-72 rounded-full bg-[#efad78]/20 blur-3xl" />
          <div className="absolute -bottom-24 left-[36%] h-56 w-56 rounded-full bg-[#a6c9b5]/25 blur-3xl" />
          <div className="relative grid items-end gap-8 lg:grid-cols-[1fr_auto]">
            <div className="rise-in">
              <div className="mb-5 flex items-center gap-2 text-xs font-medium uppercase tracking-[.17em] text-[#8b7761]">
                <CloudSun size={15} strokeWidth={1.8} />
                {now.getHours() < 12 ? 'Good morning' : now.getHours() < 18 ? 'Good afternoon' : 'Wind down well'}
              </div>
              <div className="flex items-end gap-4">
                <h1 data-testid="text-current-time" className="time-display text-[clamp(4.5rem,13vw,9rem)] font-medium text-[#263d48]">{formatTime(now)}</h1>
                <div className="mb-2 hidden h-3 w-3 rounded-full bg-[#df7b60] sm:block" />
              </div>
              <p data-testid="text-current-date" className="mt-4 text-sm text-[#6f766d] sm:text-[15px]">{formatDate(now)}</p>
            </div>
            <div className="relative flex min-w-[220px] items-center gap-4 rounded-[1.5rem] border border-[#e7d7b9] bg-[#fff9eb]/70 p-4 sm:p-5">
              <div className="sun-orb breathe flex h-14 w-14 shrink-0 items-center justify-center rounded-full text-[#fff2cc]">
                <div className="h-4 w-4 rounded-full border border-[#fff2cc]/70" />
              </div>
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#9a8066]">Next wake-up</p>
                {next ? (
                  <>
                    <p data-testid="text-next-alarm" className="mt-1 text-2xl font-semibold tracking-[-.05em] text-[#263d48]">{formatTime(next.date)}</p>
                    <p data-testid="text-next-alarm-label" className="mt-0.5 text-xs text-[#7a7e72]">{next.alarm.label} · {next.date.toLocaleDateString([], { weekday: 'short' })}</p>
                  </>
                ) : (
                  <p data-testid="text-no-next-alarm" className="mt-1 text-sm font-medium text-[#53605c]">No alarm set</p>
                )}
              </div>
            </div>
          </div>
          <div className="relative mt-8 flex flex-wrap items-center gap-3 border-t border-[#e5d6bd] pt-5 text-xs text-[#72766e]">
            <span className="flex items-center gap-1.5"><ShieldCheck size={14} className="text-[#739987]" /> Stored on this device</span>
            <span className="hidden h-1 w-1 rounded-full bg-[#c9b99d] sm:block" />
            <span className="flex items-center gap-1.5"><Clock3 size={14} className="text-[#d77b62]" /> {enabledCount} {enabledCount === 1 ? 'alarm' : 'alarms'} active</span>
            <button data-testid="button-quick-test" onClick={quickTest} className="button-lift ml-auto flex items-center gap-1.5 rounded-full bg-[#304d56] px-3.5 py-2 font-medium text-[#fff5df]">
              <Sparkles size={13} /> Try in 1 minute
            </button>
          </div>
        </section>

        <section className="mt-10">
          <div className="mb-5 flex items-end justify-between gap-4">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[.18em] text-muted-foreground">Your rhythm</p>
              <h2 className="mt-1.5 text-2xl font-semibold tracking-[-.04em] sm:text-3xl">Alarms</h2>
            </div>
            <button data-testid="button-add-alarm" onClick={openNew} className="button-lift flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground">
              <Plus size={17} /> <span className="hidden sm:inline">New alarm</span><span className="sm:hidden">Add</span>
            </button>
          </div>

          {alarms.length === 0 ? (
            <div data-testid="empty-alarms" className="glass-card flex flex-col items-center justify-center rounded-[1.7rem] px-6 py-14 text-center">
              <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-[#e8d8b5] text-[#8c6f4d]"><Moon size={25} /></div>
              <h3 className="text-xl font-semibold tracking-[-.03em]">A blank slate for better mornings</h3>
              <p className="mt-2 max-w-sm text-sm leading-6 text-muted-foreground">Add an alarm for tomorrow, or make a one-minute test alarm to hear how Sunroom wakes you.</p>
              <button data-testid="button-empty-add-alarm" onClick={openNew} className="button-lift mt-6 rounded-full bg-[#304d56] px-5 py-3 text-sm font-semibold text-[#fff5df]">Set your first alarm</button>
            </div>
          ) : (
            <div className="grid gap-3">
              {alarms.map((alarm, index) => (
                <AlarmRow key={alarm.id} alarm={alarm} index={index} onEdit={openEdit} onDelete={deleteAlarm} onToggle={toggleAlarm} />
              ))}
            </div>
          )}
        </section>

        <section className="mt-12 grid gap-3 sm:grid-cols-3">
          <InfoTile icon={<RotateCcw size={17} />} title="A little grace" text="Every alarm comes with a nine-minute snooze." />
          <InfoTile icon={<Volume2 size={17} />} title="Find your sound" text="Three gentle tones, chosen for sleepy ears." />
          <InfoTile icon={<ShieldCheck size={17} />} title="Just yours" text="Your alarms stay in this browser, on this device." />
        </section>
        <p className="mt-10 flex items-center justify-center gap-2 text-center text-xs text-muted-foreground"><Info size={13} /> Keep this tab open for alarms to ring on time.</p>
      </main>

      {isEditorOpen && <AlarmEditor initial={editingAlarm} onClose={() => setEditorOpen(false)} onSave={saveAlarm} />}
      {ringingAlarm && (
        <RingingOverlay alarm={ringingAlarm} audioBlocked={audioBlocked} onPlay={() => void start(ringingAlarm.sound).then((worked) => { setAudioBlocked(!worked); setAudioReady(worked); })} onSnooze={snooze} onDismiss={dismiss} />
      )}
      {toast && <div data-testid="status-toast" className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2 rounded-full bg-[#263d48] px-5 py-3 text-sm font-medium text-[#fff5df] shadow-[0_15px_35px_rgba(29,45,53,.25)]">{toast}</div>}
    </div>
  );
}

function AlarmRow({ alarm, index, onEdit, onDelete, onToggle }: { alarm: Alarm; index: number; onEdit: (alarm: Alarm) => void; onDelete: (id: string) => void; onToggle: (id: string) => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <article data-testid={`card-alarm-${alarm.id}`} className={`glass-card rise-in group flex items-center gap-4 rounded-[1.45rem] p-4 sm:p-5 ${!alarm.enabled ? 'opacity-60' : ''}`} style={{ animationDelay: `${index * 70}ms` }}>
      <button data-testid={`button-toggle-alarm-${alarm.id}`} onClick={() => onToggle(alarm.id)} aria-label={`${alarm.enabled ? 'Disable' : 'Enable'} ${alarm.label}`} className={`relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-colors ${alarm.enabled ? 'bg-[#e8ae77] text-[#fff8e9]' : 'bg-muted text-muted-foreground'}`}>
        {alarm.enabled ? <Bell size={19} /> : <BellOff size={19} />}
      </button>
      <button data-testid={`button-edit-alarm-${alarm.id}`} onClick={() => onEdit(alarm)} className="min-w-0 flex-1 text-left">
        <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
          <span data-testid={`text-alarm-time-${alarm.id}`} className="mono text-[2rem] leading-none tracking-[-.08em] text-foreground sm:text-[2.35rem]">{alarm.time}</span>
          {alarm.snoozeUntil && <span className="rounded-full bg-[#e8ae77]/20 px-2 py-1 text-[10px] font-semibold uppercase tracking-[.12em] text-[#b96a4e]">Snoozed</span>}
        </div>
        <p data-testid={`text-alarm-label-${alarm.id}`} className="mt-2 truncate text-sm font-medium text-foreground">{alarm.label || 'Wake-up alarm'}</p>
        <p data-testid={`text-alarm-repeat-${alarm.id}`} className="mt-1 text-xs text-muted-foreground">{daysText(alarm.repeat)} <span className="mx-1 text-border">•</span> {SOUNDS.find((sound) => sound.key === alarm.sound)?.label}</p>
      </button>
      <div className="relative">
        <button data-testid={`button-menu-alarm-${alarm.id}`} onClick={() => setMenuOpen((open) => !open)} aria-label={`Actions for ${alarm.label}`} className="flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted"><MoreHorizontal size={19} /></button>
        {menuOpen && (
          <div className="absolute right-0 top-11 z-10 w-36 overflow-hidden rounded-xl border border-border bg-card p-1.5 shadow-[0_15px_35px_rgba(32,48,56,.16)]">
            <button data-testid={`button-menu-edit-${alarm.id}`} onClick={() => { setMenuOpen(false); onEdit(alarm); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm hover:bg-muted"><Edit3 size={14} /> Edit</button>
            <button data-testid={`button-delete-alarm-${alarm.id}`} onClick={() => { setMenuOpen(false); onDelete(alarm.id); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-destructive hover:bg-muted"><Trash2 size={14} /> Delete</button>
          </div>
        )}
      </div>
    </article>
  );
}

function InfoTile({ icon, title, text }: { icon: ReactNode; title: string; text: string }) {
  return <div className="flex gap-3 rounded-[1.25rem] border border-border/50 bg-card/35 p-4"><div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#d9e6da] text-[#58806f]">{icon}</div><div><p className="text-sm font-semibold">{title}</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{text}</p></div></div>;
}

function AlarmEditor({ initial, onClose, onSave }: { initial: Alarm | null; onClose: () => void; onSave: (form: FormState) => void }) {
  const [time, setTime] = useState(initial?.time ?? `${pad(new Date().getHours())}:${pad(new Date().getMinutes())}`);
  const [label, setLabel] = useState(initial?.label ?? '');
  const [repeat, setRepeat] = useState<RepeatDay[]>(initial?.repeat ?? []);
  const [sound, setSound] = useState<Sound>(initial?.sound ?? 'soft-rise');
  const [enabled, setEnabled] = useState(initial?.enabled ?? true);
  const toggleDay = (day: RepeatDay) => setRepeat((days) => days.includes(day) ? days.filter((item) => item !== day) : [...days, day]);
  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!time) return;
    onSave({ time, label: label.trim() || 'Wake-up alarm', repeat, sound, enabled });
  };
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-[#263d48]/35 p-0 backdrop-blur-sm sm:items-center sm:p-5">
      <div className="rise-in max-h-[94dvh] w-full overflow-y-auto rounded-t-[2rem] bg-card p-6 shadow-[0_25px_70px_rgba(32,48,56,.26)] sm:max-w-lg sm:rounded-[2rem] sm:p-8">
        <div className="mb-7 flex items-start justify-between">
          <div><p className="text-[11px] font-semibold uppercase tracking-[.18em] text-muted-foreground">{initial ? 'Refine your rhythm' : 'A new beginning'}</p><h2 className="mt-2 text-2xl font-semibold tracking-[-.05em]">{initial ? 'Edit alarm' : 'Set an alarm'}</h2></div>
          <button data-testid="button-close-editor" onClick={onClose} aria-label="Close editor" className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-muted-foreground"><X size={17} /></button>
        </div>
        <form onSubmit={submit}>
          <label className="block text-xs font-semibold uppercase tracking-[.14em] text-muted-foreground" htmlFor="alarm-time">Wake at</label>
          <input data-testid="input-alarm-time" id="alarm-time" className="field mono mt-2 text-4xl tracking-[-.08em]" type="time" value={time} onChange={(event) => setTime(event.target.value)} required />
          <label className="mt-5 block text-xs font-semibold uppercase tracking-[.14em] text-muted-foreground" htmlFor="alarm-label">Name this moment</label>
          <input data-testid="input-alarm-label" id="alarm-label" className="field mt-2" placeholder="Morning walk, school run..." value={label} onChange={(event) => setLabel(event.target.value)} maxLength={36} />
          <div className="mt-6">
            <p className="text-xs font-semibold uppercase tracking-[.14em] text-muted-foreground">Repeat</p>
            <div className="mt-3 flex justify-between gap-1">
              {DAYS.map((day) => <button type="button" data-testid={`button-repeat-${day.key}`} key={day.key} title={day.name} onClick={() => toggleDay(day.key)} className={`day-button flex h-9 w-9 items-center justify-center rounded-full text-xs font-semibold ${repeat.includes(day.key) ? 'bg-[#304d56] text-[#fff5df]' : 'border border-border bg-muted/40 text-muted-foreground'}`}>{day.label}</button>)}
            </div>
            <p className="mt-2 text-xs text-muted-foreground">{daysText(repeat)}{!repeat.length ? ' · This alarm rings once' : ''}</p>
          </div>
          <div className="mt-6">
            <p className="text-xs font-semibold uppercase tracking-[.14em] text-muted-foreground">Sound</p>
            <div className="mt-3 grid gap-2">
              {SOUNDS.map((option) => <button type="button" data-testid={`button-sound-${option.key}`} key={option.key} onClick={() => setSound(option.key)} className={`flex items-center justify-between rounded-xl border p-3 text-left transition-colors ${sound === option.key ? 'border-[#d98262] bg-[#fbebd7]' : 'border-border bg-muted/20 hover:bg-muted/60'}`}><span><span className="block text-sm font-medium">{option.label}</span><span className="mt-0.5 block text-xs text-muted-foreground">{option.detail}</span></span>{sound === option.key && <Check size={17} className="text-[#c96f55]" />}</button>)}
            </div>
          </div>
          <div className="mt-6 flex items-center justify-between rounded-xl border border-border bg-muted/25 p-3.5">
            <div><p className="text-sm font-medium">Alarm enabled</p><p className="mt-0.5 text-xs text-muted-foreground">You can always pause it later</p></div>
            <button type="button" data-testid="button-editor-enabled" onClick={() => setEnabled((value) => !value)} className={`relative h-7 w-12 rounded-full transition-colors ${enabled ? 'bg-[#d98262]' : 'bg-muted-foreground/35'}`} aria-label="Toggle alarm enabled"><span className={`absolute top-1 h-5 w-5 rounded-full bg-[#fff9eb] shadow-sm transition-transform ${enabled ? 'left-6' : 'left-1'}`} /></button>
          </div>
          <div className="mt-8 flex gap-3">
            <button type="button" data-testid="button-cancel-editor" onClick={onClose} className="button-lift flex-1 rounded-full border border-border px-4 py-3 text-sm font-semibold">Cancel</button>
            <button type="submit" data-testid="button-save-alarm" className="button-lift flex-[1.4] rounded-full bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground">{initial ? 'Save changes' : 'Set alarm'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function RingingOverlay({ alarm, audioBlocked, onPlay, onSnooze, onDismiss }: { alarm: Alarm; audioBlocked: boolean; onPlay: () => void; onSnooze: () => void; onDismiss: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden bg-[#263d48] p-6 text-[#fff5df]">
      <div className="ring-pulse absolute h-[min(80vw,34rem)] w-[min(80vw,34rem)] rounded-full border border-[#f1c27e]/30 bg-[#e49368]/15" />
      <div className="ring-pulse absolute h-[min(58vw,25rem)] w-[min(58vw,25rem)] rounded-full border border-[#f1c27e]/25 bg-[#e49368]/10" style={{ animationDelay: '.35s' }} />
      <div className="relative flex w-full max-w-md flex-col items-center text-center">
        <div className="orbit absolute -top-7 h-4 w-4 rounded-full bg-[#f6ca83]" />
        <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[.22em] text-[#f2c786]"><Bell size={14} /> It is time</p>
        <div className="mt-7 flex h-28 w-28 items-center justify-center rounded-full bg-[#e49368] shadow-[0_0_0_14px_rgba(228,147,104,.13),0_0_0_34px_rgba(228,147,104,.08)]"><AlarmClock size={47} strokeWidth={1.5} /></div>
        <p data-testid="status-ringing" className="mt-9 text-[clamp(4rem,16vw,7rem)] font-medium leading-none tracking-[-.1em]">{alarm.time}</p>
        <h1 className="mt-5 text-2xl font-semibold tracking-[-.04em]">{alarm.label}</h1>
        <p className="mt-2 text-sm text-[#c4d0c8]">Take your time. The day is still yours.</p>
        {audioBlocked && <button data-testid="button-play-ringing-sound" onClick={onPlay} className="mt-5 flex items-center gap-2 rounded-full border border-[#e7b57d]/50 bg-[#f0b676]/15 px-4 py-2 text-sm text-[#f6d59e]"><VolumeX size={15} /> Tap to play sound</button>}
        <div className="mt-10 grid w-full max-w-sm grid-cols-2 gap-3">
          <button data-testid="button-snooze-alarm" onClick={onSnooze} className="button-lift flex items-center justify-center gap-2 rounded-full border border-[#c5d5ca]/30 bg-[#46616a] px-5 py-4 text-sm font-semibold"><Pause size={16} /> Snooze 9 min</button>
          <button data-testid="button-dismiss-alarm" onClick={onDismiss} className="button-lift flex items-center justify-center gap-2 rounded-full bg-[#f6d18f] px-5 py-4 text-sm font-semibold text-[#263d48]"><Check size={16} /> Dismiss</button>
        </div>
      </div>
    </div>
  );
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={AppContent} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;